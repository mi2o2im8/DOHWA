import { BrowserRouter, Routes, Route } from 'react-router'
import HomePage from './pages/HomePage'
// 커뮤니티
import CommunityPage from './pages/CommunityPage'
// 작업방
import RoomsPage from './pages/RoomsPage'
// 클립
import ClipsPage from './pages/ClipsPage'
// 작가 찾기
import ArtistsPage from './pages/ArtistsPage'

// 공용 헤더
import Header from './components/Header'


function App() {
  return (
    <BrowserRouter>
      {/* 공용 컴포넌트 */}
      {/* 헤더 */}
      <Header />  

      <Routes>
        {/* 페이지들 */}
        {/* 메인홈페이지 */}
        <Route path='/' element={<HomePage />} />
        {/* 커뮤니티 */}
        <Route path='/community' element={<CommunityPage />}/>
        {/* 작업방 */}
        <Route path='/rooms' element={<RoomsPage />} />
        {/* 클립 */}
        <Route path='/clip' element={<ClipsPage />} />
        {/* 작가 찾기 */}
        <Route path='/artist' element={<ArtistsPage />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App